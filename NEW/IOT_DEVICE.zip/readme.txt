Project Name: Sarlls-IOT
Project Version: #efc70d19
Project Url: https://www.flux.ai/sarlls1/sarlls-iot

Project Description:
ESP32 Automotive High-Side Switch Board with 3G Connectivity and Robust 12V Protection

Project Properties:

Power plane definition:
Inner layer 2 as ground plane; inner layer 3 as 12 V power plane

PWR_HC netclass:
2 oz copper high-current routing


